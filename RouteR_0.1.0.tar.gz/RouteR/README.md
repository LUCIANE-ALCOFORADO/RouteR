## RouteR
Pacote para auxiliar o usuário a construir o modelo de programação linear inteira para o problema de roteamento de veículos, saindo do ponto 1, visitando vários pontos e retornando ao ponto 1. Para obter uma solução ótima usa-se o pacote lpSolve nas dependências desse pacote.
